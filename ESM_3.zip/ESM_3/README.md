# Online Resource 3 — source-traceable secondary-data decisions

**Article:** When microplastic measurements are comparable: an estimand-first critical review of Vietnamese studies  
**Journal:** Environmental Science and Pollution Research  
**Authors:** Cong Ngoc Phan, The Tam Le, Thi Ngoc Anh Nguyen, Dang Minh Hien Phan  
**Corresponding author:** Cong Ngoc Phan  
**Affiliations:** School of BioChemical and Environmental Technologies, Vinh University, 182 Le Duan, Truong Vinh, Nghe An 43000, Vietnam; Chemistry Department, Vinh University, 182 Le Duan, Truong Vinh, Nghe An 43000, Vietnam  
**Correspondence:** phancongngoc@vinhuni.edu.vn  
**Package:** Online Resource 3 (initial-submission materials)

## Scope
The catalogue has 101 records; 14 purposive reports support seven worked-case families and 19 specified decisions. Four additional post hoc decisions use four non-core reports. These are illustrations, not a national census or independent hold-out validation. No archived prospective rule freeze, blinded duplicate human extraction or reviewer-agreement dataset is claimed. Full-text reinspection supports the source-specific daily effluent-emission application using the source-defined average daily treated/discharged volume and final-effluent concentration; this does not convert concentration reduction into flow-integrated load removal.

## Run offline with Python 3.10 or later
```sh
python -m pip install -r requirements.txt
python code/analyze_revision.py
python code/summarize_reuse_pairs.py
python code/check_workbook.py
python code/check_integrity.py
```
The numerical analysis uses the standard library. openpyxl is required for workbook checking/rebuilding. The code reads canonical local inputs, not primary PDFs or network services.

To compare the separately submitted workbook (this writes `outputs/workbook_verification_external.json` without overwriting the reproducible default report):
```sh
python code/check_workbook.py --external /path/to/ESM_2.xlsx
```
To rebuild after synchronized input changes:
```sh
python code/build_workbook.py
python code/analyze_revision.py
python code/summarize_reuse_pairs.py
python code/check_workbook.py
```
Rebuilding can alter archive bytes/timestamps. Regenerate checksums and replace BOTH distributed workbook copies together. The released copies are byte-identical.

## Package contents
- `ESM_2.xlsx`: 18 sheets, 56 formula cells with explicit cached results.
- `inputs/`: current records, operational dictionaries, 138 per-gate rationales, calculations and bounded source conflicts.
- `code/`: numerical analysis, workbook builder, supported-formula checker and checksum verifier.
- `outputs/`: regenerated arithmetic, decisions and verification reports.
- `provenance/`: inherited PDF/comparator manifests, current bibliographic ledger and targeted reinspection boundaries.
- `history/`: clearly labelled earlier snapshots; NEVER read by current analytical scripts.
- `checksums.sha256`: all released package members except this manifest itself.

## Current safeguards
Collection apertures, preparation sieves, pores, pixels and reporting intervals remain distinct. N, n and c remain source-stratum-specific. Printed shrimp species counts and coherent aggregate composition are not silently reconciled. Rayon-including and rayon-excluding targets answer different questions. Concentration reduction is not unconditionally load reduction. The My 2023 SI's apparent mass-based recovery is not particle-count recovery; fish-tissue wording in a shrimp source remains an applicability conflict. The S02 blank pathway remains NE without inferring absent practice. Legacy dependence IDs are isolated as LEGACY-S, not current S01–S14.

## Verification boundary
Checks cover source keys, disjoint core/additional membership, 138 matching gate rationales, all 4,096 valid gate-state combinations, 23 calculations, six matched-question links, 56 formula caches and identical workbook copies. They establish computational/internal consistency, NOT adequate source interpretation, primary-data validity, independent human validation or journal acceptance. The 30 cited DOI metadata records were checked; the full 101-record catalogue was not comprehensively reappraised. Primary article PDFs are not redistributed. Author review of source interpretations, naming conventions and submission declarations is required.


Historical preparation records are archived separately from the analytical inputs; they do not establish a journal submission or decision.
