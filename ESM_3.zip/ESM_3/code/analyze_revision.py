#!/usr/bin/env python3
"""Reproduce the bounded worked comparisons from local, source-linked inputs.
No source retrieval, sampling, invented measurements or independent-review claims.
"""
from pathlib import Path
import csv,json,math,hashlib,itertools
ROOT=Path(__file__).resolve().parents[1]
def read(n):return json.loads((ROOT/'inputs'/(n+'.json')).read_text(encoding='utf-8'))
def calc(row):
 v=row['Inputs'];op=row['Operation']
 if op=='ratio':
  if not v[1]:raise ValueError('Zero denominator')
  return v[0]/v[1]
 if op=='complement':return 1-v[0]
 if op=='reduction':
  if not v[0]:raise ValueError('Zero input concentration')
  return 1-v[1]/v[0]
 if op=='sum':return sum(v)
 if op=='product':return math.prod(v)
 raise ValueError('Unknown operation: '+op)
def classify(row):
 g=[row[k] for k in ['Source_scope','Target_definition','Quantity_basis','Measurement_domain','Count_consistency','Design_for_inference']]
 assert all(x in ['Pass','Fail','Unresolved','Not required'] for x in g)
 if 'Fail' in g:return 'Not supported for stated purpose'
 if 'Unresolved' in g:return 'Unresolved for stated purpose'
 return 'Supported for stated limited purpose'
def write_csv(name,rows):
 with (ROOT/'outputs'/name).open('w',encoding='utf-8-sig',newline='') as f:
  dw=csv.DictWriter(f,fieldnames=list(rows[0]));dw.writeheader();dw.writerows(rows)
def main():
 (ROOT/'outputs').mkdir(exist_ok=True)
 cats=read('catalogue');src=read('case_sources');ev=read('case_evidence');d=read('decisions')
 assert len(cats)==101 and len({r['Pub_ID'] for r in cats})==101
 assert not {'VNMP-2020-007','VNMP-2021-006'} & {r['Pub_ID'] for r in cats}
 assert len(src)==14 and len({r['Source_ID'] for r in src})==14
 assert sum(r['Case_selected'] for r in cats)==14
 assert len(ev)==154 and len({(r['Source_ID'],r['Field']) for r in ev})==154
 fields={r['Field'] for r in read('field_codebook')};assert len(fields)==11
 for s in src:assert {r['Field'] for r in ev if r['Source_ID']==s['Source_ID']}==fields
 for r in ev:
  assert r['State'] in {'RP','ND','NE','NR','NA'}
  if r['State'] in {'RP','ND'}:assert r['Evidence'] and r['Locator'],r
 out=[]
 for r in read('calculations'):
  v=calc(r); assert math.isfinite(v)
  if r['Result_unit']=='fraction':assert 0<=v<=1
  out.append({**r,'Inputs':json.dumps(r['Inputs']),'Result':v})
 a={r['Calculation_ID']:r['Result'] for r in out}
 assert abs(a['A01']-76/725)<1e-12 and abs(a['A02']-57/368)<1e-12
 assert a['A07']==33 and a['A09']==103 and a['A10']==105 and a['A11']==25
 assert abs(a['A12']-.359)<1e-12 and abs(a['A13']-.276)<1e-12
 assert a['A19']==10 and a['A20']==45000 and a['A21']==1.8
 dr=[{**r,'Outcome':classify(r)} for r in d]
 challenge=[{**r,'Outcome':classify(r)} for r in read('challenge_set')]
 assert len(challenge)==4 and len({r['Decision_ID'] for r in challenge})==4
 core={r['Pub_ID'] for r in src};extra={x.strip() for r in challenge for x in r['Pub_IDs'].split(';')}
 assert not core & extra and extra <= {r['Pub_ID'] for r in cats}
 ids={r['Source_ID'] for r in src}
 for row in d:assert {x.strip() for x in row['Source_IDs'].split(';')} <= ids
 for name in ['case_evidence','size_domains','confirmation','calculations']:
  for row in read(name):assert row['Source_ID'] in ids
 gr=read('gate_rationales');gc=read('gate_codebook');lookup={r['Decision_ID']:r for r in d+challenge};gf={r['Gate_ID']:r['Field'] for r in gc}
 assert len(gr)==6*(len(d)+len(challenge)) and len({(r['Decision_ID'],r['Gate_ID']) for r in gr})==len(gr)
 for row in gr:assert row['Rationale'] and row['Locator'] and row['State']==lookup[row['Decision_ID']][gf[row['Gate_ID']]]
 legacy={r['Legacy_source_ID'] for r in read('legacy_source_crosswalk')}
 for row in read('dependence'):assert {x.strip() for x in row['Source_IDs'].split(';') if x.strip()} <= legacy
 tests=0
 for states in itertools.product(['Pass','Fail','Unresolved','Not required'],repeat=6):
  expected='Not supported for stated purpose' if 'Fail' in states else ('Unresolved for stated purpose' if 'Unresolved' in states else 'Supported for stated limited purpose')
  assert classify(dict(zip(gf.values(),states)))==expected;tests+=1
 wr=[{**r,'Computed_reduction':a[r['Calculation_ID']]} for r in read('wastewater_stages')]
 for r in wr:assert round(r['Computed_reduction']*100)==r['Source_rounded_percent']
 write_csv('calculations.csv',out);write_csv('comparison_decisions.csv',dr);write_csv('challenge_set.csv',challenge);write_csv('wastewater_stages.csv',wr)
 summary={'reference_records':len(cats),'purposive_case_reports':len(src),'case_families':7,'case_field_observations':len(ev),'specified_comparison_decisions':len(dr),'post_hoc_challenge_decisions':len(challenge),'post_hoc_challenge_reports':len(extra),'per_gate_rationales':len(gr),'exhaustive_gate_combinations_checked':tests,'calculations':len(out),'wastewater_stage_range_percent':[min(r['Computed_reduction']*100 for r in wr),max(r['Computed_reduction']*100 for r in wr)],'independent_human_extraction_completed':False,'interpretation':'Purposive examples plus additional post hoc applications; not hold-out validation or national prevalence.'}
 (ROOT/'outputs/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 result={'status':'PASS','checks':['Unique canonical references and excluded-identity absence','Fourteen selected reports and eleven defined fields per report','Positive evidence locators','Finite source-linked arithmetic','Shrimp target and species-count reconstruction','Five wastewater stage calculations match rounded source table','Question-specific gate evaluation; no additive study score','Four additional applications; CH03 source-defined daily emission verified and CH04 load-removal barrier retained'],'limitations':['Does not independently validate primary measurements','Does not establish human inter-reviewer reliability','Does not reconstruct historical search exports or missing particle data']}
 (ROOT/'outputs/analysis_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
