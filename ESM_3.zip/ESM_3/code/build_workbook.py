from pathlib import Path
from copy import copy
import json,math,re,zipfile,xml.etree.ElementTree as ET,textwrap,sys
from openpyxl import Workbook,load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table,TableStyleInfo
from openpyxl.workbook.properties import CalcProperties
P=Path(__file__).resolve().parents[1];W=P;OUT=P/'ESM_2.xlsx'
sys.path.insert(0,str(P/'code'))
from analyze_revision import calc,classify
read=lambda n:json.loads((P/'inputs'/(n+'.json')).read_text())
meta=read('metadata');wb=Workbook();wb.remove(wb.active);wb.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True)
navy='17365D';light='E9EFF6';ink='1C2833';green='1C5D48';orange='FFF2D8'
cache={};data_rows={}
def text(v):
 if v is None:return ''
 if isinstance(v,(list,dict)):return json.dumps(v,ensure_ascii=False)
 s=str(v)
 return re.sub(r'\bAI2-', 'SRC-',s)
def sheet(name,title,rows,widths=None):
 ws=wb.create_sheet(name);ws.sheet_view.showGridLines=False;ws.sheet_view.zoomScale=85
 cols=list(rows[0]) if rows else ['Information'];nc=len(cols)
 for rr,msg in [(1,title),(2,meta['Title']),(3,meta['Journal']+' | '+meta['Author']+' | '+meta['Email']),(4,'Source-linked working data. Question-specific decisions are not additive study-quality scores.')]:
  ws.merge_cells(start_row=rr,start_column=1,end_row=rr,end_column=max(nc,3));c=ws.cell(rr,1,msg)
  c.font=Font(name='Calibri',size=14 if rr==1 else 10,bold=rr==1,color='FFFFFF' if rr==1 else ink)
  c.fill=PatternFill('solid',fgColor=navy if rr==1 else 'FFFFFF');c.alignment=Alignment(wrap_text=True,vertical='center')
  ws.row_dimensions[rr].height=30 if rr<3 else 24
 for j,h in enumerate(cols,1):
  c=ws.cell(5,j,h.replace('_',' '));c.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor=navy);c.alignment=Alignment(wrap_text=True,vertical='center')
  width=(widths or {}).get(h,20 if h.endswith('_ID') or h in ['DOI','Field','State','Year_recorded','Case_selected'] else 48)
  ws.column_dimensions[get_column_letter(j)].width=width
 ws.row_dimensions[5].height=35
 for i,r in enumerate(rows,6):
  height=25
  for j,h in enumerate(cols,1):
   v=r.get(h,'');v=text(v) if not isinstance(v,(int,float)) else v;c=ws.cell(i,j,v)
   c.font=Font(name='Calibri',size=10,color=green);c.alignment=Alignment(wrap_text=True,vertical='top')
   width=ws.column_dimensions[get_column_letter(j)].width
   est=sum(max(1,math.ceil(len(line)/max(8,width*.96))) for line in str(v).split('\n'))
   height=max(height,est*13+8)
   if h in ['Source_URL','DOI_or_URL'] and isinstance(v,str) and v.startswith('http'):c.hyperlink=v
   if h in ['State','Count_status','Current_disposition'] and ('Unresolved' in str(v) or v=='NE'):c.fill=PatternFill('solid',fgColor=orange)
  ws.row_dimensions[i].height=min(360,height)
 ws.freeze_panes='C6' if nc>5 else 'A6';ws.auto_filter.ref=f'A5:{get_column_letter(nc)}{max(5,len(rows)+5)}';ws.print_title_rows='1:5'
 ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A3;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
 ws.print_options.horizontalCentered=True
 data_rows[name]=(6,5+len(rows));return ws
catalog=read('catalogue')
ws=sheet('01_Reference_catalogue','Canonical reference catalogue (context and case selection)',catalog,{'Title':70,'Full_citation':95,'Authors':44,'Source_boundary':80,'Origin':46,'DOI':34,'Source_URL':48,'Matrix_recorded':26})
case=read('case_sources')
ws=sheet('02_Case_sources','Fourteen purposively selected primary reports and inspected sources',case,{'Citation':30,'Full_citation':95,'Inspected_locator':30,'Access_scope':55,'Selection_reason':60,'Supplement_scope':56,'SHA256':68,'DOI':34,'Source_URL':48,'Source_file':30})
ws=sheet('03_Case_evidence','Source-linked field observations (not a complete-reporting audit)',read('case_evidence'),{'Evidence':92,'Locator':36,'Scope':60,'Boundary':76,'Field':30,'Source_URL':48})
ws=sheet('04_Size_domains','Size information separated by role and particle metric',read('size_domains'),{'Compartment':28,'Shape':18,'Size_role':32,'Unit':18,'Statement':66,'Locator':35,'Boundary':74,'Lower':15,'Upper':18})
decisions=read('decisions');dr=[{**r,'Outcome':''} for r in decisions]
ws=sheet('05_Comparison_decisions','Applied comparison decisions: question-specific gates',dr,{'Question':72,'Family':25,'Reason':76,'Permitted_output':70,'Not_permitted':68,'Information_to_resolve':76,'Outcome':45,**{k:24 for k in ['Source_scope','Target_definition','Quantity_basis','Measurement_domain','Count_consistency','Design_for_inference']}})
for row,d in enumerate(decisions,6):
 f=f'=IF(COUNTIF(E{row}:J{row},"Fail")>0,"Not supported for stated purpose",IF(COUNTIF(E{row}:J{row},"Unresolved")>0,"Unresolved for stated purpose","Supported for stated limited purpose"))'
 ws.cell(row,15,f);ws.cell(row,15).font=Font(name='Calibri',size=10,color='000000',bold=True);cache[(ws.title,f'O{row}')]=classify(d)
ws=sheet('06_Confirmation','Tested, eligible and assigned populations remain distinct',read('confirmation'),{'Population':65,'Selection':52,'Count_status':65,'Boundary':80,'Locator':38,'Tested_n':17,'Eligible_N':17,'Assigned_c':17})
cr=[]
for r in read('calculations'):
 d={'Calculation_ID':r['Calculation_ID'],'Label':r['Label'],'Operation':r['Operation']}
 d.update({f'Input_{j+1}':v for j,v in enumerate(r['Inputs']+['']*(7-len(r['Inputs'])))})
 d.update(Result='',Result_unit=r['Result_unit'],Source_ID=r['Source_ID'],Locator=r['Locator'],Boundary=r['Boundary']);cr.append(d)
ws=sheet('07_Calculations','Reproducible transformations of explicitly sourced values',cr,{'Label':72,'Operation':18,**{f'Input_{i}':16 for i in range(1,8)},'Result':20,'Result_unit':18,'Locator':50,'Boundary':85})
ri={r['Calculation_ID']:i for i,r in enumerate(read('calculations'),6)}
for row,r in enumerate(read('calculations'),6):
 formula={'ratio':f'=D{row}/E{row}','complement':f'=1-D{row}','reduction':f'=1-E{row}/D{row}','sum':f'=SUM(D{row}:J{row})','product':f'=D{row}*E{row}'}[r['Operation']]
 ws.cell(row,11,formula);ws.cell(row,11).font=Font(name='Calibri',size=10,color='000000',bold=True);ws.cell(row,11).number_format='0.00%' if r['Result_unit']=='fraction' else '#,##0.00'
 cache[(ws.title,f'K{row}')]=calc(r)
 if r['Operation']=='complement':ws.cell(row,4).number_format='0.0%'
for target,origin in [('A08','A07'),('A21','A20')]:
 row=ri[target];ws.cell(row,4,f'=K{ri[origin]}');cache[(ws.title,f'D{row}')]=calc(next(r for r in read('calculations') if r['Calculation_ID']==origin))
# The assignment numerator and the source-inclusive shrimp target are themselves explicit sums.
row=ri['A03'];ws.cell(row,4,f'=K{ri["A22"]}');cache[(ws.title,f'D{row}')]=34;ws.cell(row,4).comment=None
row=ri['A06'];ws.cell(row,4,f'=K{ri["A23"]}');cache[(ws.title,f'D{row}')]=98
ws=sheet('08_Source_conflicts','Source discrepancies and bounded dispositions',read('source_conflicts'),{'Topic':52,'Source_A_locator':50,'Source_A':90,'Source_B_locator':50,'Source_B':90,'Disposition':96,'Pub_ID':32})
ws=sheet('09_Selection_log','Explicit inclusion, exclusion and current-case selection decisions',read('selection_log'),{'Title':86,'Source_basis':64,'Current_disposition':50,'Reason':90,'Scope_note':85,'DOI_or_URL':55,'Record_ID':28})
ws=sheet('10_Dependence','Potentially shared observations: keep bibliographic and sampling units distinct',read('dependence'),{'Relationship':55,'Evidence':100,'Implication':80,'Boundary':85,'Sources':80})
cb=read('field_codebook');
for r in cb:r['Rule']=r['Rule'].replace('05_Size_domains','04_Size_domains')
ws=sheet('11_Codebook','Operational rules for eleven fields and five evidence states',cb,{'Field':32,'Label':35,'RP_minimum':88,'Do_not_infer':86,'Rule':100})
state_start=20
for j,h in enumerate(['State','Meaning','Operational rule'],1):
 c=ws.cell(state_start,j,h);c.fill=PatternFill('solid',fgColor=navy);c.font=Font(name='Calibri',size=10,bold=True,color='FFFFFF')
for i,r in enumerate(read('evidence_states'),state_start+1):
 for j,key in enumerate(['State','Meaning','Rule'],1):
  c=ws.cell(i,j,r[key]);c.font=Font(name='Calibri',size=10,color=ink);c.alignment=Alignment(wrap_text=True,vertical='top')
 ws.row_dimensions[i].height=70
ws.merge_cells('A28:E28');ws['A28']='Gate outcomes: any Fail -> not supported; otherwise any Unresolved -> unresolved; otherwise supported only for the explicitly stated limited purpose. These are not study rankings.';ws['A28'].alignment=Alignment(wrap_text=True);ws.row_dimensions[28].height=42
ws=sheet('12_Metadata_changes','Canonical DOI synchronization from the preceding source bibliography',read('metadata_changes'),{'Record':26,'Field':16,'Before':52,'After':40,'Source':78,'Disposition':92})
challenge=read('challenge_set'); ch=[{**r,'Outcome':''} for r in challenge]
ws=sheet('13_Challenge_set','Additional post hoc applications; not independent validation',ch,{'Challenge_type':34,'Pub_IDs':34,'Question':78,'Reason':92,'Permitted_output':76,'Not_permitted':76,'Information_to_resolve':78,'Locator':72,'Source_URL':58,'Outcome':45,**{k:24 for k in ['Source_scope','Target_definition','Quantity_basis','Measurement_domain','Count_consistency','Design_for_inference']}})
for row,d in enumerate(challenge,6):
 f=f'=IF(COUNTIF(E{row}:J{row},"Fail")>0,"Not supported for stated purpose",IF(COUNTIF(E{row}:J{row},"Unresolved")>0,"Unresolved for stated purpose","Supported for stated limited purpose"))'
 ws.cell(row,17,f);ws.cell(row,17).font=Font(name='Calibri',size=10,color='000000',bold=True);cache[(ws.title,f'Q{row}')]=classify(d)
ws=sheet('14_Gate_codebook','Operational requirements for six non-additive gates',read('gate_codebook'),{'Gate_ID':16,'Field':30,'Label':42,'Pass_minimum':85,'Fail_condition':85,'Unresolved_condition':85,'Not_required_condition':85})
ws=sheet('15_Gate_rationales','One source-linked rationale per gate and decision',read('gate_rationales'),{'Decision_ID':18,'Gate_ID':16,'Gate':42,'State':24,'Requirement':65,'Rationale':95,'Source_IDs_or_Pub_IDs':38,'Locator':86})
ws=sheet('16_Legacy_crosswalk','Crosswalk for inherited contextual source identifiers',read('legacy_source_crosswalk'),{'Legacy_source_ID':24,'Linked_publication_records':66,'Recorded_source_URLs':98,'Boundary':94})
ws=sheet('17_Reuse_summary','Matched questions and evidence needed for stronger reuse',read('paired_reuse_summary'),{'Pair_ID':16,'Evidence_base':36,'Limited_decision':20,'Supported_limited_use':90,'Stronger_decision':20,'Stronger_use':90,'Controlling_barrier':100,'Next_evidence':100})
# Workbook entry page; no all-field missingness score or national prevalence label.
ws=wb.create_sheet('00_Readme',0);ws.sheet_view.showGridLines=False;ws.sheet_view.zoomScale=90
for col,width in [('A',42),('B',32),('C',78),('D',42)]:ws.column_dimensions[col].width=width
for rr,val in [(1,'Online Resource 2 | Source-traceable methodological review'),(2,meta['Title']),(3,meta['Journal']+' | '+meta['Author']+' | '+meta['Email']),(4,'14 purposive worked-case reports within a 101-reference contextual catalogue, plus four post hoc challenge decisions from four additional catalogue reports. No exhaustive national census, reporting-prevalence estimate or independent human reliability statistic is claimed.')]:
 ws.merge_cells(start_row=rr,start_column=1,end_row=rr,end_column=4);c=ws.cell(rr,1,val);c.font=Font(name='Calibri',size=15 if rr==1 else 11,bold=rr==1,color='FFFFFF' if rr==1 else ink);c.fill=PatternFill('solid',fgColor=navy if rr==1 else 'FFFFFF');c.alignment=Alignment(wrap_text=True,vertical='center');ws.row_dimensions[rr].height=35 if rr!=4 else 46
metrics=[('Contextual reference records',"=COUNTA('01_Reference_catalogue'!A6:A106)",101,'Catalogue size is not a national-population denominator.'),('Selected primary reports',"=COUNTA('02_Case_sources'!A6:A19)",14,'Thirteen supplied primary PDFs and one publisher main text.'),('Specified comparisons',f"=COUNTA('05_Comparison_decisions'!A6:A{5+len(decisions)})",len(decisions),'A decision is conditional on its own question; it is not a quality score.'),('Source-field observations',"=COUNTA('03_Case_evidence'!A6:A159)",154,'Eleven operationally defined fields per case report; partial evidence retained.'),('Source-linked calculations',f"=COUNTA('07_Calculations'!A6:A{5+len(cr)})",len(cr),'Calculated values do not independently validate original measurements.'),('Post hoc challenge decisions',f"=COUNTA('13_Challenge_set'!A6:A{5+len(challenge)})",len(challenge),'Illustrative applications; no prospective freeze or independent validation.')]
for row,(label,f,val,boundary) in enumerate(metrics,6):
 ws.cell(row,1,label);ws.cell(row,2,f);cache[(ws.title,f'B{row}')]=val;ws.merge_cells(start_row=row,start_column=3,end_row=row,end_column=4);ws.cell(row,3,boundary);ws.row_dimensions[row].height=32
ws['A12']='Independent human re-extraction';ws['B12']='Not completed';ws.merge_cells('C12:D12');ws['C12']='No human reviewer identity or inter-reviewer agreement result is fabricated.';ws.row_dimensions[12].height=38
ws.merge_cells('A13:D13');ws['A13']=meta['Affiliation'];ws['A13'].alignment=Alignment(wrap_text=True);ws.row_dimensions[13].height=34
ws.merge_cells('A14:D14');ws['A14']='Navigation and interpretation';ws['A14'].fill=PatternFill('solid',fgColor=navy);ws['A14'].font=Font(name='Calibri',size=12,bold=True,color='FFFFFF');ws.row_dimensions[14].height=27
purpose={
'01_Reference_catalogue':'One canonical DOI/citation record per reference; 14 case flags.',
'02_Case_sources':'Case selection, exact inspected pages, source versions, URLs and supplied-PDF checksums.',
'03_Case_evidence':'Located evidence states; a positive detail is not a resolved comparison window.',
'04_Size_domains':'Collection, preparation, pore, imaging, observed and reported size roles are separate.',
'05_Comparison_decisions':'Actual questions, six gates, allowed outputs, barriers and information needed.',
'06_Confirmation':'N, n and c are different populations; conflict and selection boundaries retained.',
'07_Calculations':'Editable Excel formulas reproduce the case-specific arithmetic.',
'08_Source_conflicts':'Both source statements and their bounded dispositions; no silent source repair.',
'09_Selection_log':'Khuyen included as a case; previous exclusions and other candidates explicitly disposed.',
'10_Dependence':'Possible dataset reuse is not inferred away from different titles or DOIs.',
'11_Codebook':'All eleven fields, five evidence states and the comparison gate rule.',
'12_Metadata_changes':'Historical DOI synchronization and current cited-reference amendments.',
'13_Challenge_set':'Four additional applications from four non-core reports; source and inference boundaries retained.',
'14_Gate_codebook':'Pass, Fail, Unresolved and Not required requirements.',
'15_Gate_rationales':'138 per-gate source-linked rationales.',
'16_Legacy_crosswalk':'Separate LEGACY-S namespace, not current S01–S14.',
'17_Reuse_summary':'Six source-linked matched-question contrasts and next evidence; no new observations.'}
for row,(name,note) in enumerate(purpose.items(),15):
 ws.cell(row,1,name);ws.cell(row,1).hyperlink=f"#'{name}'!A1";ws.merge_cells(start_row=row,start_column=2,end_row=row,end_column=4);ws.cell(row,2,note);ws.row_dimensions[row].height=30
for row in ws:
 for c in row:
  if c.value is not None and c.row not in [1,14]:
   c.font=Font(name='Calibri',size=11,bold=c.column==1,color='000000' if c.data_type=='f' else ink);c.alignment=Alignment(wrap_text=True,vertical='center')
ws.freeze_panes='A15';wb.active=0
wb.properties.creator=meta['Author'];wb.properties.title=meta['Title'];wb.properties.subject='Bounded source-traceable methodological comparisons';wb.properties.description='One canonical data version; linked source values and formula-based calculations.'
wb.save(OUT)
# Explicitly cached independently computed values preserve openpyxl formatting and hyperlinks.
# The final verifier recomputes every formula independently and checks the stored cached value.
NS={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
with zipfile.ZipFile(OUT) as z:parts={n:z.read(n) for n in z.namelist()}
for idx,ws in enumerate(wb.worksheets,1):
 path=f'xl/worksheets/sheet{idx}.xml';tree=ET.fromstring(parts[path])
 for c in tree.findall('.//s:c',NS):
  key=(ws.title,c.attrib['r'])
  if key not in cache:continue
  v=c.find('s:v',NS)
  if v is None:v=ET.SubElement(c,'{'+NS['s']+'}v')
  value=cache[key]
  if isinstance(value,str):c.set('t','str');v.text=value
  else:c.pop('t',None) if False else None;c.attrib.pop('t',None);v.text=format(value,'.16g')
 parts[path]=ET.tostring(tree,encoding='utf-8',xml_declaration=True)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as z:
 for n,b in parts.items():z.writestr(n,b)
(P/'outputs/formula_expected.json').write_text(json.dumps([{'Sheet':s,'Cell':c,'Expected':v} for (s,c),v in cache.items()],indent=2))
print('WORKBOOK',OUT,'sheets',len(wb.worksheets),'cached formulas',len(cache))
