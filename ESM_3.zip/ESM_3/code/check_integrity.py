from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1];errors=[];n=0
for line in (r/'checksums.sha256').read_text().splitlines():
 h,name=line.split('  ',1);p=r/name
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:errors.append(name)
 n+=1
print(json.dumps({'status':'PASS' if not errors else 'FAIL','files_checked':n,'errors':errors},indent=2))
raise SystemExit(bool(errors))
