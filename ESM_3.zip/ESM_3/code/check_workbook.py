#!/usr/bin/env python3
"""Verify canonical table data, formulas, cached values and an optional external copy.
Only the formula subset used in this workbook is evaluated; this is not a general Excel engine.
"""
from pathlib import Path
import argparse,ast,csv,hashlib,json,math,re
from openpyxl import load_workbook
from analyze_revision import calc,classify,read
ROOT=Path(__file__).resolve().parents[1]
NAME='ESM_2.xlsx'
def valtext(x):
 if x is None:return ''
 if isinstance(x,(list,dict)):x=json.dumps(x,ensure_ascii=False)
 return re.sub(r'\bAI2-','SRC-',str(x))
def safe_arithmetic(s):
 node=ast.parse(s,mode='eval').body
 def f(n):
  if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)):return n.value
  if isinstance(n,ast.UnaryOp) and isinstance(n.op,ast.USub):return -f(n.operand)
  if isinstance(n,ast.BinOp):
   a,b=f(n.left),f(n.right)
   if isinstance(n.op,ast.Add):return a+b
   if isinstance(n.op,ast.Sub):return a-b
   if isinstance(n.op,ast.Mult):return a*b
   if isinstance(n.op,ast.Div):return a/b
  raise ValueError('Unsupported arithmetic')
 return f(node)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--workbook',type=Path,default=ROOT/NAME);ap.add_argument('--external',type=Path);args=ap.parse_args()
 wf=load_workbook(args.workbook,data_only=False);wv=load_workbook(args.workbook,data_only=True)
 errors=[];evaluated={};visiting=set()
 def region(spec,sheet):
  if '!' in spec:
   sh,rg=spec.split('!',1);sh=sh.strip("'")
  else:sh,rg=sheet,spec
  rg=rg.replace('$','')
  return [value(sh,c.coordinate) for row in wf[sh][rg] for c in row]
 def value(sh,cell):
  key=(sh,cell)
  if key in evaluated:return evaluated[key]
  if key in visiting:raise ValueError('Circular formula')
  c=wf[sh][cell];v=c.value
  if c.data_type!='f':return v
  visiting.add(key);f=v[1:]
  if f.startswith('COUNTA('):result=sum(x is not None and x!='' for x in region(f[7:-1],sh))
  elif f.startswith('SUM('):result=sum(x for x in region(f[4:-1],sh) if isinstance(x,(int,float)))
  elif f.startswith('IF(COUNTIF('):
   m=re.fullmatch(r'IF\(COUNTIF\(([^,]+),"Fail"\)>0,"([^"]+)",IF\(COUNTIF\(([^,]+),"Unresolved"\)>0,"([^"]+)","([^"]+)"\)\)',f)
   if not m:raise ValueError('Unsupported conditional: '+f)
   r1,a,r2,b,c=m.groups();result=a if 'Fail' in region(r1,sh) else (b if 'Unresolved' in region(r2,sh) else c)
  else:
   expr=re.sub(r'\$?([A-Z]+)\$?(\d+)',lambda m:repr(value(sh,m.group(1)+m.group(2))),f)
   result=safe_arithmetic(expr)
  visiting.remove(key);evaluated[key]=result;return result
 formulas=0
 for ws in wf:
  for row in ws:
   for c in row:
    if c.data_type=='e':errors.append(f'Excel error: {ws.title}!{c.coordinate}')
    if c.data_type!='f':continue
    formulas+=1
    try:
     expected=value(ws.title,c.coordinate);cached=wv[ws.title][c.coordinate].value
     same=math.isclose(expected,cached,rel_tol=1e-12,abs_tol=1e-12) if isinstance(expected,(int,float)) and isinstance(cached,(int,float)) else expected==cached
     if not same:errors.append(f'Cached mismatch {ws.title}!{c.coordinate}: {cached!r} != {expected!r}')
    except Exception as e:errors.append(f'Formula {ws.title}!{c.coordinate}: {e}')
 # Canonical row checks for all data tables except the mixed-content codebook/readme and calculated columns.
 mapping={'01_Reference_catalogue':'catalogue','02_Case_sources':'case_sources','03_Case_evidence':'case_evidence','04_Size_domains':'size_domains','06_Confirmation':'confirmation','08_Source_conflicts':'source_conflicts','09_Selection_log':'selection_log','10_Dependence':'dependence','12_Metadata_changes':'metadata_changes','13_Challenge_set':'challenge_set','05_Comparison_decisions':'decisions','14_Gate_codebook':'gate_codebook','15_Gate_rationales':'gate_rationales','16_Legacy_crosswalk':'legacy_source_crosswalk','17_Reuse_summary':'paired_reuse_summary'}
 checked_cells=0
 for sh,n in mapping.items():
  rows=read(n);keys=list(rows[0]);ws=wv[sh]
  for i,r in enumerate(rows,6):
   for j,k in enumerate(keys,1):
    actual=ws.cell(i,j).value;expected=r.get(k,'')
    if not (math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-12) if isinstance(actual,(int,float)) and isinstance(expected,(int,float)) else valtext(actual)==valtext(expected)):errors.append(f'Canonical mismatch {sh}!{ws.cell(i,j).coordinate}')
    checked_cells+=1
 cats={r['Pub_ID']:r for r in read('catalogue')}
 for s in read('case_sources'):
  if s['DOI']!=cats[s['Pub_ID']]['DOI']:errors.append('Case DOI mismatch: '+s['Source_ID'])
 for i,r in enumerate(read('decisions'),6):
  if wv['05_Comparison_decisions'].cell(i,15).value!=classify(r):errors.append('Decision mismatch: '+r['Decision_ID'])
 for i,r in enumerate(read('challenge_set'),6):
  if wv['13_Challenge_set'].cell(i,17).value!=classify(r):errors.append('Challenge decision mismatch: '+r['Decision_ID'])
 for i,r in enumerate(read('calculations'),6):
  v=wv['07_Calculations'].cell(i,11).value
  if not isinstance(v,(int,float)) or not math.isclose(v,calc(r),rel_tol=1e-12,abs_tol=1e-12):errors.append('Calculation mismatch: '+r['Calculation_ID'])
 for ws in wf:
  for row in ws:
   for c in row:
    if c.data_type=='f' and '#REF!' in c.value:errors.append('Broken reference')
    if c.hyperlink and c.hyperlink.target and c.hyperlink.target.startswith("#'"):
     name=c.hyperlink.target.split("'")[1]
     if name not in wf.sheetnames:errors.append('Broken navigation: '+name)
 h=hashlib.sha256(args.workbook.read_bytes()).hexdigest();external_match=None
 if args.external:
  external_match=h==hashlib.sha256(args.external.read_bytes()).hexdigest()
  if not external_match:errors.append('External workbook differs from package workbook')
 # Small boundary tests on current arithmetic and decision logic.
 for op,arr in [('ratio',[1,0]),('reduction',[0,1])]:
  try:calc({'Operation':op,'Inputs':arr});errors.append('Zero-denominator test failed')
  except ValueError:pass
 report={'status':'PASS' if not errors else 'FAIL','workbook':args.workbook.name,'sha256':h,'sheets':len(wf.sheetnames),'formula_cells':formulas,'formula_caches_checked':formulas,'canonical_cells_checked':checked_cells,'external_copy_byte_identical':external_match,'errors':errors,'verification_boundary':'Internal consistency and reproducibility, not independent validation of primary sources.'}
 target=ROOT/'outputs'/('workbook_verification_external.json' if args.external else 'workbook_verification.json')
 target.write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
 if errors:raise SystemExit(1)
if __name__=='__main__':main()
