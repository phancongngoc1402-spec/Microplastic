#!/usr/bin/env python3
"""Render the explicit six-gate rule as a deterministic diagram, not empirical data.
Optional: install requirements_figures.txt. This is not required for arithmetic checking.
Article: When microplastic measurements are comparable: an estimand-first critical review of Vietnamese studies
Journal: Environmental Science and Pollution Research
Author: Cong Ngoc Phan; Vinh University; phancongngoc@vinhuni.edu.vn
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
OUT=Path(__file__).resolve().parents[1]/'outputs';OUT.mkdir(exist_ok=True)
fig,ax=plt.subplots(figsize=(6.85,5.5));ax.set_xlim(0,10);ax.set_ylim(0,10);ax.axis('off')
def box(x,y,w,h,text,fs=9):
 ax.add_patch(Rectangle((x,y),w,h,fill=False,linewidth=1))
 ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,wrap=True)
def arrow(a,b,label=None):
 ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','lw':1})
 if label:ax.text((a[0]+b[0])/2+.10,(a[1]+b[1])/2,label,fontsize=8)
box(1,8.5,8,1.2,'Specify output, particle target, quantity and inference')
box(1,6.8,8,1.2,'Record source evidence, access and rationale for six gates\nG01 Source • G02 Target • G03 Quantity • G04 Domain\nG05 Counts/strata • G06 Inference design',8.5)
arrow((5,8.5),(5,8.0));box(1,5.0,4.1,1.1,'Any required gate = Fail?');arrow((5,6.8),(3,6.1))
box(6.0,5.0,3.6,1.1,'Not supported\nfor stated purpose');arrow((5.1,5.55),(6,5.55),'Yes')
box(1,3.0,4.1,1.1,'Otherwise, any required\ngate = Unresolved?');arrow((3,5.0),(3,4.1),'No')
box(6.0,3.0,3.6,1.1,'Unresolved\nfor stated purpose');arrow((5.1,3.55),(6,3.55),'Yes')
box(1,1.1,8.6,1.1,'Otherwise: Supported for stated limited purpose\nPass or justified Not required for every gate');arrow((3,3.0),(3,2.2),'No')
ax.text(5,.30,'Outcomes are non-additive and are not study-quality scores',ha='center',va='center',fontsize=9)
fig.tight_layout(pad=.2)
fig.savefig(OUT/'Fig1.eps',format='eps');fig.savefig(OUT/'Fig1.tif',format='tiff',dpi=1200,pil_kwargs={'compression':'tiff_lzw'});fig.savefig(OUT/'Fig1_preview.png',dpi=220)
plt.close(fig)
