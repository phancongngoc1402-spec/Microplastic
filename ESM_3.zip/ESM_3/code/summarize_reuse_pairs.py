#!/usr/bin/env python3
"""Check derived paired-question links; do not reassign any source gate."""
from pathlib import Path
import csv, json
from analyze_revision import classify
ROOT=Path(__file__).resolve().parents[1]
read=lambda n:json.loads((ROOT/'inputs'/f'{n}.json').read_text())
records={r['Decision_ID']:r for name in ['decisions','challenge_set'] for r in read(name)}
rows=read('paired_reuse_summary')
assert len(rows)==6
assert len({r['Pair_ID'] for r in rows})==len(rows)
output=[]
for row in rows:
 a,b=records[row['Limited_decision']],records[row['Stronger_decision']]
 assert classify(a)=='Supported for stated limited purpose'
 assert classify(b) in ['Unresolved for stated purpose','Not supported for stated purpose']
 for value,key in [('Supported_limited_use','Permitted_output')]:assert row[value]==a[key]
 for value,key in [('Stronger_use','Question'),('Controlling_barrier','Reason'),('Next_evidence','Information_to_resolve')]:assert row[value]==b[key]
 output.append({**row,'Limited_outcome':classify(a),'Stronger_outcome':classify(b)})
with (ROOT/'outputs/paired_reuse_summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
report={'status':'PASS','derived_pairs':len(rows),'new_observations':0,'new_gate_assignments':0,'boundary':'Source-derived contrasts, not a validation sample or performance estimate.'}
(ROOT/'outputs/paired_reuse_verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
