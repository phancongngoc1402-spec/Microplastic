# Current editorial release — 16 November 2026

This release reframes the review around estimand-specific reuse, moves detailed source-audit material to Supplement S12, and adds six derived contrasts in main Table 6, Supplement S13 and workbook sheet 17_Reuse_summary. No source evidence, gate states or observations were added. The 21 evidence-input hashes remain unchanged.

Current document checks: main manuscript 17 PDF pages, 6 tables, 1 figure, 4 Office equations, 30 DOI-bearing references and 6 keywords; editable supplement 13 PDF pages and 8 tables. Workbook: 18 sheets, 56 checked formula caches. See provenance/editorial_release_validation.json for the current machine-readable checks and limitations. All author declarations still require author confirmation.

The earlier validation is retained only as history/inherited_editorial_release_validation_2026-10-08.json. The following notes are historical, not the current release date.

---

# Editorial revision notes (8 October 2026)

Scope: presentation, academic English, captions, source attribution, bibliographic initials and reproduction-package synchronisation.

Scientific boundaries and original measurements are not changed. The 14-core/4-additional design and the source-conflict records remain conditional.

Publisher verification: https://vjst.vast.vn/jse/article/view/18616 lists Duc Hieu Phung (Phung DH) for Doan et al. (2023).

**Action required before submission:** Confirm named authors, their individual contributions, agreement to the submission, funding disclosures, competing interests and the corresponding author's contact details. No such approvals or declarations were inferred.

The separate ESM_2.xlsx and the copy in this package must have identical SHA-256 hashes.

The optional external-workbook check writes a separate verification report, so the default offline reproduction commands do not invalidate the package checksum manifest.
